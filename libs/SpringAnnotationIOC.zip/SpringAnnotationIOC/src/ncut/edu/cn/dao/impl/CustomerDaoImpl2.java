package ncut.edu.cn.dao.impl;

import org.springframework.stereotype.Repository;

import ncut.edu.cn.dao.ICustomerDao;

/**
 * ģ��ͻ��ĳ־ò�ʵ����
 * @author ncut
 *
 */
@Repository("customerDao2")
public class CustomerDaoImpl2 implements ICustomerDao {

	@Override
	public void saveCustomer() {
		// TODO Auto-generated method stub
		System.out.print("�־ò㱣���˿ͻ�22222");
	}

}
