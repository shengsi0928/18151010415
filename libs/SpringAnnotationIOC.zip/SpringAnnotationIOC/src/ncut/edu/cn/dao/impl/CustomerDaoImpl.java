package ncut.edu.cn.dao.impl;

import org.springframework.stereotype.Repository;

import ncut.edu.cn.dao.ICustomerDao;

/**
 * ģ��ͻ��ĳ־ò�ʵ����
 * @author ncut
 *
 */
@Repository("customerDao1")
public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public void saveCustomer() {
		// TODO Auto-generated method stub
		System.out.print("�־ò㱣���˿ͻ�11111");
	}

}
