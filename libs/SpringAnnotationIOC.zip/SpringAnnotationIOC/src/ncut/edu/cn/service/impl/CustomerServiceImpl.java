package ncut.edu.cn.service.impl;


import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import ncut.edu.cn.dao.ICustomerDao;
import ncut.edu.cn.service.ICustomerService;

/**
 * �ͻ���ҵ���ʵ����
 * @author ncut
 *@Component
 */
@Service("customerService")
@Scope("prototype")
public class CustomerServiceImpl implements ICustomerService {

	@Value("̰˯��è")
	private String sName;
//	@Autowired
//	@Qualifier("customerDao2")
	@Resource(name="customerDao1")
	private ICustomerDao customerDao=null;
	
	@Override
	public void saveCustom() {
		System.out.println("ҵ�����ó־ò㡣������"+sName);
		customerDao.saveCustomer(); 

	}

}
