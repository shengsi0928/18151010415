package ncut.edu.cn;

import ncut.edu.cn.dao.ICustomerDao;
import ncut.edu.cn.service.ICustomerService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {	
	public static void main(String[] args) {
		ApplicationContext aContext=new ClassPathXmlApplicationContext("bean.xml");
		ICustomerService csService1=(ICustomerService) aContext.getBean("customerService");
//		System.out.println(csService);
		
		//csService1.saveCustom();
		
		ICustomerService csService2=(ICustomerService) aContext.getBean("customerService");
		System.out.println(csService1==csService2);
		}

}
